from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import sqlite3
import random
import os

app = Flask(__name__)
CORS(app)

DB = "skill_gap.db"

SUBJECTS = ["Python", "DSA", "DBMS", "Computer Networks", "OS", "Math", "English", "Physics", "Chemistry", "Software Engineering"]
NAMES = [
    "Ravi Kumar", "Priya Sharma", "Arjun Reddy", "Sneha Patel", "Kiran Rao",
    "Anjali Singh", "Rohit Verma", "Divya Nair", "Manoj Gupta", "Pooja Iyer",
    "Suresh Babu", "Lakshmi Devi", "Rahul Mehta", "Deepa Krishnan", "Vijay Naidu",
    "Ananya Das", "Sanjay Joshi", "Meera Pillai", "Aakash Tiwari", "Swati Bhatt",
    "Narender Reddy", "Kavya Menon", "Harish Yadav", "Rekha Saxena", "Tarun Malhotra"
]
DEPTS = ["Computer Science", "Electronics", "Mechanical", "Civil"]


def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            roll TEXT UNIQUE NOT NULL,
            department TEXT,
            semester INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS marks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            subject TEXT NOT NULL,
            max_marks INTEGER NOT NULL,
            obtained INTEGER NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(id)
        )
    """)

    # Seed random students if empty
    c.execute("SELECT COUNT(*) FROM students")
    if c.fetchone()[0] == 0:
        used_names = set()
        for i in range(20):
            name = random.choice([n for n in NAMES if n not in used_names])
            used_names.add(name)
            roll = f"22CS{str(i+1).zfill(3)}"
            dept = random.choice(DEPTS)
            sem = random.randint(1, 8)

            c.execute("INSERT INTO students (name, roll, department, semester) VALUES (?,?,?,?)",
                      (name, roll, dept, sem))
            sid = c.lastrowid

            num_subjects = random.randint(4, 6)
            chosen = random.sample(SUBJECTS, num_subjects)
            for subj in chosen:
                max_marks = 100
                # Make some students fail, some low, some pass
                roll_type = random.random()
                if roll_type < 0.2:        # 20% fail
                    obtained = random.randint(20, 39)
                elif roll_type < 0.45:     # 25% low
                    obtained = random.randint(40, 59)
                else:                       # 55% pass
                    obtained = random.randint(60, 98)
                c.execute("INSERT INTO marks (student_id, subject, max_marks, obtained) VALUES (?,?,?,?)",
                          (sid, subj, max_marks, obtained))

        conn.commit()
    conn.close()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/students", methods=["GET"])
def get_students():
    conn = get_db()
    students = conn.execute("SELECT * FROM students ORDER BY name").fetchall()
    result = []
    for s in students:
        marks = conn.execute("SELECT * FROM marks WHERE student_id=?", (s["id"],)).fetchall()
        subjects = []
        for m in marks:
            pct = round((m["obtained"] / m["max_marks"]) * 100)
            status = "fail" if pct < 40 else "low" if pct < 60 else "pass"
            subjects.append({
                "subject": m["subject"],
                "max_marks": m["max_marks"],
                "obtained": m["obtained"],
                "percentage": pct,
                "status": status
            })
        result.append({
            "id": s["id"],
            "name": s["name"],
            "roll": s["roll"],
            "department": s["department"],
            "semester": s["semester"],
            "subjects": subjects
        })
    conn.close()
    return jsonify(result)


@app.route("/api/students/<int:sid>", methods=["GET"])
def get_student(sid):
    conn = get_db()
    s = conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
    if not s:
        return jsonify({"error": "Not found"}), 404
    marks = conn.execute("SELECT * FROM marks WHERE student_id=?", (sid,)).fetchall()
    subjects = []
    for m in marks:
        pct = round((m["obtained"] / m["max_marks"]) * 100)
        status = "fail" if pct < 40 else "low" if pct < 60 else "pass"
        subjects.append({
            "id": m["id"],
            "subject": m["subject"],
            "max_marks": m["max_marks"],
            "obtained": m["obtained"],
            "percentage": pct,
            "status": status
        })
    conn.close()
    return jsonify({
        "id": s["id"], "name": s["name"], "roll": s["roll"],
        "department": s["department"], "semester": s["semester"],
        "subjects": subjects
    })


@app.route("/api/students", methods=["POST"])
def add_student():
    data = request.json
    conn = get_db()
    try:
        c = conn.cursor()
        c.execute("INSERT INTO students (name, roll, department, semester) VALUES (?,?,?,?)",
                  (data["name"], data["roll"], data.get("department",""), data.get("semester", 1)))
        sid = c.lastrowid
        for subj in data.get("subjects", []):
            c.execute("INSERT INTO marks (student_id, subject, max_marks, obtained) VALUES (?,?,?,?)",
                      (sid, subj["subject"], subj["max_marks"], subj["obtained"]))
        conn.commit()
        conn.close()
        return jsonify({"success": True, "id": sid})
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({"error": "Roll number already exists"}), 400


@app.route("/api/students/<int:sid>", methods=["PUT"])
def update_student(sid):
    data = request.json
    conn = get_db()
    conn.execute("UPDATE students SET name=?, roll=?, department=?, semester=? WHERE id=?",
                 (data["name"], data["roll"], data.get("department",""), data.get("semester",1), sid))
    conn.execute("DELETE FROM marks WHERE student_id=?", (sid,))
    for subj in data.get("subjects", []):
        conn.execute("INSERT INTO marks (student_id, subject, max_marks, obtained) VALUES (?,?,?,?)",
                     (sid, subj["subject"], subj["max_marks"], subj["obtained"]))
    conn.commit()
    conn.close()
    return jsonify({"success": True})


@app.route("/api/students/<int:sid>", methods=["DELETE"])
def delete_student(sid):
    conn = get_db()
    conn.execute("DELETE FROM marks WHERE student_id=?", (sid,))
    conn.execute("DELETE FROM students WHERE id=?", (sid,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})


@app.route("/api/stats", methods=["GET"])
def stats():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    all_marks = conn.execute("SELECT obtained, max_marks FROM marks").fetchall()
    fail_students = set()
    low_students = set()
    marks_rows = conn.execute("SELECT student_id, obtained, max_marks FROM marks").fetchall()
    for row in marks_rows:
        pct = round((row["obtained"] / row["max_marks"]) * 100)
        if pct < 40:
            fail_students.add(row["student_id"])
        elif pct < 60:
            low_students.add(row["student_id"])
    conn.close()
    return jsonify({
        "total_students": total,
        "fail_count": len(fail_students),
        "low_count": len(low_students - fail_students),
        "pass_count": total - len(fail_students) - len(low_students - fail_students)
    })


if __name__ == "__main__":
    init_db()
    print("✅ Database ready with 20 sample students!")
    print("🌐 Open http://localhost:5000 in your browser")
    app.run(debug=True, port=5000)
